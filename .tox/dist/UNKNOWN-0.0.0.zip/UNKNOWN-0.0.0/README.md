**to run**

``
$ python3 example.py
``
